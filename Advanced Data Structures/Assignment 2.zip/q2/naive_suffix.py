#Eric Horng
#26935449

#Added depth to this one

class Node:
    def __init__(self,is_leaf, label = 0):
        if is_leaf:
            self.is_leaf = True
            self.label = label
        else:
            self.is_leaf = False
        self.depth = 0
        self.Edges = {}            

    def add_edge(self,edge,edge_label):
        self.Edges[edge_label] = edge

    def delete_edge(self,edge_label): #Remove by edge label
        self.Edges.pop(edge_label)

    def get_edge(self,edge_label):
        return self.Edges[edge_label]

class Edge:
    def __init__(self,string,dest):
        self.substring = string
        self.dest = dest
        
    def get_length(self):
        return len(self.substring)

class Naive_Suffix_Tree:
    def __init__(self,string):
        self.string = string
        self.string_length = len(string)
        self.nodes = [Node(False)]
        self.internal_nodes = []
        self.Active = 0

    def traverse(self,substring):
        self.active_node = 0 #Start from root
        self.active_edge = None
        self.split = 0
        for k in range(len(substring)):
            if self.active_edge is None:
                self.active_edge = self.nodes[self.active_node].get_edge(substring[k])
                self.split += 1
            else:
                self.split += 1

            if self.split == self.active_edge.get_length():
                if self.nodes[self.active_edge.dest].is_leaf is True:
                    return self.active_node,self.active_edge, -1
                    
                self.active_node = self.active_edge.dest
                self.active_edge = None
                self.split = 0

        return self.active_node, self.active_edge, self.split

    def build(self):
        #Create I_1
        self.nodes.append(Node(True,0))
        new_edge = Edge(self.string[0],1)
        self.nodes[0].add_edge(new_edge,self.string[0])
        
        for i in range(self.string_length-1):
            for j in range(i+2):
                active_node, active_edge, split = self.traverse(self.string[j:i+1])
                if split == -1: #path ended at a leaf
                    active_edge.substring = active_edge.substring + self.string[i+1] #Append i+1 char to edge
                elif active_edge == None: #Perform rule 2a or rule 3
                    if self.string[i+1] not in self.nodes[active_node].Edges:
                        self.nodes.append(Node(True,j)) #Create new leaf node with label j
                        new_edge = Edge(self.string[i+1],len(self.nodes)-1) #Create edge between active node and new leaf
                        self.nodes[active_node].add_edge(new_edge,self.string[i+1])
                elif split>0 and active_edge is not None: #Perform rule 2b or rule 3
                    if active_edge.substring[split] != self.string[i+1]:
                        old_substring = active_edge.substring
                        old_dest = active_edge.dest
                        
                        #Create a new node
                        self.nodes.append(Node(False))
                                                
                        #Modify existing edge to point from active to new node
                        active_edge.dest = len(self.nodes)-1
                        active_edge.substring = old_substring[0:split]
                        self.internal_nodes.append(len(self.nodes)-1)
                        
                        #Create a new edge between new node and old leaf
                        new_edge = Edge(old_substring[split:],old_dest)
                        self.nodes[-1].add_edge(new_edge,old_substring[split])

                        #Modify label depths for LCS 
                        self.nodes[-1].depth = self.nodes[active_node].depth+split
                        
                        #Create new leaf
                        self.nodes.append(Node(True,j))
                        
                        #Create new edge between new node and new leaf
                        new_edge = Edge(self.string[i+1],len(self.nodes)-1)
                        self.nodes[-2].add_edge(new_edge,self.string[i+1])
                    
