#Eric Horng
#26935449

import naive_suffix
import sys
#Naive_suffix in this folder has variables to track the label depth for each internal node

def DFS(suffix_array,nodes,nodeidx): #Reusing from q1, dont really need to sort lexographically, but dont wanna break it
    current_node = nodes[nodeidx]
    if current_node.is_leaf is True:
        return current_node.label
    edge_labels = sorted(current_node.Edges) #Sort lexographically
    for edges in edge_labels:
        suffix_array.append(DFS(suffix_array,nodes,current_node.Edges[edges].dest))

if __name__ == '__main__':
    filename1 = sys.argv[1]
    filename2 = sys.argv[2]
    
    with open(filename1,'r') as string1_file:
        string1 = string1_file.read()

    with open(filename2,'r') as string2_file:
        string2 = string2_file.read()
            
    concat_string = string1 + '#' + string2 + '$'
    string1_length = len(string1)
    string2_length = len(string2)
    suffix_tree = naive_suffix.Naive_Suffix_Tree(concat_string)
    suffix_tree.build()
    suffix_leaves = [[] for k in range(len(suffix_tree.internal_nodes))]
    depths = [0]*len(suffix_tree.internal_nodes)
    contains_both = [False]*len(suffix_tree.internal_nodes)

    #For each internal node, gather attached and subtree leaves and fetch label depth
    for k in range(len(depths)):
        depths[k] = suffix_tree.nodes[suffix_tree.internal_nodes[k]].depth
        DFS(suffix_leaves[k],suffix_tree.nodes,suffix_tree.internal_nodes[k])

    #Check if the internal node contains suffixes for both strings    
    for k in range(len(suffix_leaves)):
        contains_string1 = False
        contains_string2 = False
        for j in range(len(suffix_leaves[k])):
            if suffix_leaves[k][j] is not None:
                if suffix_leaves[k][j] <= string1_length-1:
                    contains_string1 = True
                elif suffix_leaves[k][j] > string1_length:
                    contains_string2 = True

        if (contains_string1 == True) and (contains_string2 == True):
            contains_both[k] = True

    #Find the node with the largest label depth    
    max_depth = max(depths)
    max_nodes = [suffix_tree.internal_nodes[i] for i, j in enumerate(depths) if j==max_depth]

    #Get LCS indexes and output to file
    with open('output_lcs.txt','w+') as output_file:
        output_file.write(str(max_depth) + '\n') #Write LCS length to file

        for k in max_nodes:
            string1_index = 0
            string2_index = 9999999999
            max_common_node = suffix_tree.nodes[k]
            leaves = []
            for edge_label in max_common_node.Edges: #Gather direct leaves for each internal node
                if suffix_tree.nodes[max_common_node.Edges[edge_label].dest].is_leaf:
                    leaf_label = suffix_tree.nodes[max_common_node.Edges[edge_label].dest].label
                    leaves.append(leaf_label)

            string1_index = min(leaves) #Find leftmost index in string 1
            for k in range(len(leaves)): #Find leftmost index in string 2 
                if string2_index > leaves[k] and leaves[k] >= string1_length+1:
                    string2_index = leaf_label

            output_file.write(str(string1_index) + ' ' + str(string2_index - string1_length - 1) + '\n') #String2 indexes are at an offset as we concatonated
        print("DONE!")
