#Eric Horng
#26935449
import Fib_Heap

class NPC:
    def __init__(self,start,adventurer,treasure_map,number_of_vertices):
        self.start = start
        self.treasure_map = treasure_map
        self.graph = {k: {} for k in range(number_of_vertices)}
        for k in self.treasure_map: #Reformat into dictionary
            self.graph[k[0]][k[1]] = k[2]
        self.adventurer1 = adventurer
        self.adventurer2 = None
        self.shortest_path_to_nodes = None
        self.previous_node = None
        self.path = None
        self.raw_path = None
        self.time_to_finish = 0

    def find_treasure(self,goal,number_of_vertices): #Use Dijkstra's shortest path algorithm with Fibonacci Heap to find shortest path to treasure
        distances = [99999]*number_of_vertices #Initially set distance to all paths to infinity
        previous = [None]*number_of_vertices #Previous node
        nodes = [None]*number_of_vertices #Stores pointers for decrease_key in Fibonacci heap
        distances[self.start] = 0
        priority_queue = Fib_Heap.Fibonacci_Heap()
        for k in range(number_of_vertices):
            nodes[k] = priority_queue.insert(distances[k],k)

        while priority_queue.is_empty() is False:
            u = priority_queue.extract_min()
            for v, distance in self.graph[u.value].items():
                new_dist = distances[u.value] + distance
                if new_dist < distances[v]:
                    distances[v] = new_dist
                    previous[v] = [u.value, distance]
                    priority_queue.decrease_key(nodes[v],new_dist)
        self.shortest_path_to_nodes = distances
        self.previous_node = previous
        self.time_to_finish = distances[goal]
        return distances[goal]
        
    def generate_path(self,previous_nodes,goal):
        path = [goal]
        time = []
        current = goal
        while current != self.start: #Get the path from treasure to start, along with the weight
            path.append(previous_nodes[current][0])
            time.append(previous_nodes[current][1])
            current = previous_nodes[current][0]
        time.append(0)
        path = path[::-1] #Reverse the path as we started from the treasure
        time = time[::-1]
        for k in range(len(path)-1): #Get the cumulative weight (i.e. time taken to get to node)
            time[k+1] = time[k] + time[k+1]
        path_tuple = []
        for k in range(len(path)):
            path_tuple.append(tuple((path[k],time[k])))
        self.path = path_tuple
        self.raw_path = path
        return path_tuple

    def is_pair(self):
        if adventurer2 is None:
            return False
        else:
            return True
