#Eric Horng
#26935449
import math

class Node:
    def __init__(self,key,value):
        self.key = key
        self.value = value 
        self.parent = None 
        self.child = None 
        self.left = None
        self.right = None
        self.degree = 0
        self.mark = False

class Fibonacci_Heap:
    root_list = None
    min_node = None
    number_of_nodes = 0

    def merge(self,heap2):
        temp = heap2.root_list.left
        heap2.root_list.left = self.root_list.left #Make heap1 root left sibling left sibling of heap2 root
        self.root_list.left.right = heap2.root_list #Make heap2 right sibling of original heap1 left sibling

        self.root_list.left = temp #Make heap2 left sibling left sibling of heap 1
        self.root_list.left.right = self.root_list #Make heap1 right sibling of original left sibling of heap2

        if heap2.min_node.key < self.min_node.key:
            self.min_node = heap2.min_node
        self.number_of_nodes += heap2.number_of_nodes
        
    def insert(self,key,value):
        new_node = Node(key,value)
        new_node.left = new_node
        new_node.right = new_node
        if self.root_list is None: #If inserting the very first node
            self.root_list = new_node
            self.min_node = new_node
        else:
            self.add_to_root(new_node)
            if new_node.key < self.min_node.key:
                self.min_node = new_node
        self.number_of_nodes += 1
        return new_node #Return pointer for use in decrease_key

    def consolidate(self,current):
        Aux = [None]*int(math.log2(self.number_of_nodes)+2) #Height of is tree is less than log2(N)
        Stop_Flag = False
        Last_Node = current.left
        while Stop_Flag is False:
            while Aux[current.degree] is not None:
                if current.key > Aux[current.degree].key:
                    self.merge_consilidate(Aux[current.degree],current)
                    Aux[current.degree] = None
            if current == Last_Node:
                Stop_Flag = True
            current = current.right

        new_min = self.make_array(self.root_list)    
        for i in range(0, len(new_min)):
            if new_min[i].key < self.min_node.key:
                self.min_node = new_min[i]    

    def merge_consolidate(self,node1,node2): #Merge two nodes that are in the same root list with node1<node2
        #Remove node 2 from the root list
        self.remove_from_root(node2)

        #Make node2 child of node1
        if node1.child is None:
            node1.child = node2
            node2.left = node2 #Maintain double linked list property
            node2.right = node2
        else:
            node2.right = node1.child.right #Slot node 2 of on right side of node1 pointer
            node2.left = node1.child
            node1.child.right.left = node2
            node1.child.right = node2
        node1.degree += 1
        node2.parent = node1
        node2.mark = False #Unmark when becomes a child
        return node1

    def find_min(self):
        return self.min_node

    def extract_min(self):
        extracted_node = self.min_node
        if extracted_node is None:
            print("Heap is empty")
            return
        else:
            if extracted_node.child is not None: #Attach children to root list
                children = self.make_array(extracted_node.child)
                for child in children:
                    self.add_to_root(child)
                    child.parent = None
            self.remove_from_root(self.min_node)
            
            if extracted_node == extracted_node.right: #If only node in heap
                self.min_node = None
                self.root_list = None
            else:
                self.min_node = extracted_node.right
                self.consolidate(self.root_list)
        self.number_of_nodes -= 1
        return extracted_node

    def decrease_key(self,node,new_key):
        node.key = new_key
        if node.parent is not None and node.key < node.parent.key: 
            self.cut(node,node.parent)
        if node.key < self.min_node.key:
            self.min_node = node
            
    def cut(self,node1,node2): #node1 is child, node2 is parent
        if node2.child == node2.child.right: #node2 only has node 1 as a child
            node2.child = None
        elif node2.child == node1: #Node 1 is directly node2's child, so shift the pointer to a sibling
            node2.child = node1.right
            node1.right.parent = node1
        node1.left.right = node1.right
        node1.right.left = node1.left
        node2.degree -= 1
        self.add_to_root(node1)
        node1.mark = False #Unmark as going to root
        node1.parent = None
        #Do a cascading cut if parent is marked
        if node2.parent is not None:
            if node2.mark:
                self.cut(node2,node2.parent)
            else:
                node2.mark = True
    
    def make_array(self,node): #Return all the siblings of a node for easy access
        array = []
        Last_Node = node.left
        Stop_Flag = False
        while Stop_Flag is False:
            if node == Last_Node:
                array.append(node)
                node = node.right
                Stop_Flag = True
            else:
                array.append(node)
                node = node.right
        return array
        
    def add_to_root(self,node): #Make right sibling of root list node
        if self.root_list is None:
            self.root_list = node
        else:
            node.right = self.root_list.right
            node.left = self.root_list
            self.root_list.right.left = node
            self.root_list.right = node

    def remove_from_root(self,node):
        if node == self.root_list:
            self.root_list = node.right
        node.left.right = node.right
        node.right.left = node.left
        
    def is_empty(self):
        if self.number_of_nodes == 0:
            return True
        else:
            return False

    def get_length(self):
        return self.number_of_nodes

#=============Test Cases        
##a = Fibonacci_Heap()
##b = []
##for k in range(4,10):
##    b.append(a.insert(k,1))
##print("Extracted key: " + str(a.extract_min().key))
##print("Extracted key: " + str(a.extract_min().key))
##
##x = Fibonacci_Heap()
##y = x.insert(11,1)
##a.decrease_key(b[-1],-5)
##m = x.insert(6,10)
##print("Extracted key: " + str(a.extract_min().key))
##print("Extracted key: " + str(a.extract_min().key))
##a.merge(x)
##
##
##print("Extracted key: " + str(a.extract_min().key))
##
##b = []
##for k in range(0,15):
##    b.append(a.insert(k,1))
##
##print("Extracted key: " + str(a.extract_min().key))
##a.decrease_key(b[3],-1)
##print("Extracted key: " + str(a.extract_min().key))

#Results: 4,5,-5,6,6,0,-1,1,2,4,5,6,7,7,8,8,9,10,11,11,12,13,14,Heap is empty

    
        
        

    
        
