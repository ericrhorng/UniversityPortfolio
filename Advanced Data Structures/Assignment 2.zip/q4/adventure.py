#Eric Horng
#26935449
import NPC_Class
import sys

def main(): #Driver for script
    number_of_vertices = int(sys.argv[1])
    goal = int(sys.argv[2])
    adventurers = []
    finish_times = []
    
    for arg in sys.argv[3:]:
        f = open(arg,'r')
        f_read = f.read().splitlines()
        weights = [-1]*(len(f_read)-1) #Initialize weights array
        for x in range(0,len(f_read)-1):
            weights[x] = list(map(int,f_read[x+1].split())) #Split by whitespace and convert to int
            
        new_adventurer = NPC_Class.NPC(int(f_read[0]),x,weights,number_of_vertices)
        treasure_time = new_adventurer.find_treasure(goal,number_of_vertices) #Find path to shortest node
        new_adventurer.generate_path(new_adventurer.previous_node,goal) #Get the path to treasure
        finish_times.append(treasure_time)
        adventurers.append(new_adventurer)

    #Aggregate the paths, grouping by time
    timeline = {} #At time t, store the node each adventurer is at, or not if travelling between nodes
    for k in range(len(adventurers)):
        for j in range(1,len(adventurers[k].path)):
            node = adventurers[k].path[j][0]
            time_taken = adventurers[k].path[j][1]
            if time_taken in timeline:
                timeline[time_taken].append([node,k])
            else:
                timeline[time_taken] = [[node,k]]
                        
    #Match adventurers that meet at the same node at the same time
    pairs = []
    is_paired = [False]*len(adventurers)
    for key in sorted(timeline): #Sort in ascending order by time so we match at the first node and not the 2nd or 3rd etc.
        matches = timeline[key]
        if len(matches)>=2:
            for x in range(len(matches)):
                for y in range(x+1,len(matches)):
                    match1 = matches[x][1]
                    match2 = matches[y][1]
                    if (matches[x][0] == matches[y][0]) and (is_paired[match1] is False) and (is_paired[match2] is False):
                        new_pair = NPC_Class.NPC(matches[y][0],match1,adventurers[match1].treasure_map+adventurers[match2].treasure_map,number_of_vertices) #Create a new adventurer instance to find shortest path to treasure
                        new_pair.adventurer2 = match2 #Store matching adventurers
                        treasure_time = new_pair.find_treasure(goal,number_of_vertices) #Calculate shortest path from meeting to treasure
                        new_pair.generate_path(new_pair.previous_node,goal) #Generate this path
                        pairs.append(new_pair)
                        is_paired[match1] = True #So matched adventurers dont match again
                        is_paired[match2] = True

    #Recalculate time to treasure for each adventurer that is in a pair
    for k in range(len(pairs)):
        current_pair = pairs[k]
        npc1 = current_pair.adventurer1
        npc2 = current_pair.adventurer2
        
        idx = adventurers[npc1].raw_path.index(current_pair.start) #Get subpath from the start to the meeting node
        adventurers[npc1].raw_path = adventurers[npc1].raw_path[0:idx] + current_pair.raw_path
        adventurers[npc1].time_to_finish = adventurers[npc1].path[idx][1] + current_pair.time_to_finish #Get time to meeting node + time from meeting node to treasure
        finish_times[npc1] = adventurers[npc1].path[idx][1] + current_pair.time_to_finish

        idx = adventurers[npc2].raw_path.index(current_pair.start) #Get subpath from the start to the meeting node
        adventurers[npc2].raw_path = adventurers[npc2].raw_path[0:idx] + current_pair.raw_path
        adventurers[npc2].time_to_finish = adventurers[npc2].path[idx][1] + current_pair.time_to_finish
        finish_times[npc2] = adventurers[npc2].path[idx][1] + current_pair.time_to_finish

    #Find adventurers that have shortest time to treasure and output to file
    minimum = min(finish_times)
    indices = [i for i, v in enumerate(finish_times) if v == minimum]
    
    with open("output_adventure.txt","w+") as output_file:
        output_file.write(str(minimum) + "\n")
        for i in indices:  
            for j in adventurers[i].raw_path:
                output_file.write(str(j)+ " ")
            output_file.write("\n")

    print("DONE")
if __name__ == '__main__':
    main()
