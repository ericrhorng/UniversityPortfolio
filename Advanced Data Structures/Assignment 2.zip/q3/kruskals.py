#Eric Horng
#26935449
import sys
def find(a,parent): #From lecture slides
    while (parent[a] >= 0):
        a = parent[a]
    return a

def union(a,b,parent): #Union-by-height from lecture slides
    root_a = find(a,parent)
    root_b = find(b,parent)
    if (root_a == root_b):
        return 0

    height_a = -parent[root_a]
    height_b = -parent[root_b]

    if (height_a > height_b):
        parent[root_b] = root_a
    elif (height_b > height_a):
        parent[root_a] = root_b
    else:
        parent[root_a] = root_b
        parent[root_b] = -(height_b+1)
    return 1

if __name__ == '__main__':
    V_size = int(sys.argv[1])
    f = open(sys.argv[2],"r")
    output_file = open("output_kruskals.txt","w+")
    f_read = f.read().splitlines() 
    weights = [-1]*len(f_read)

    for x in range(len(f_read)):
        weights[x] = list(map(int,f_read[x].split())) #Split by whitespace and convert to int

    weights = sorted(weights, key = lambda x: x[2]) #Sort in ascending order
    V = [-1]*V_size
    total_weight = 0
    tree_edges = []

    for x in range(len(weights)):
        if len(tree_edges) == V_size-1:
            break
        k = weights[x]
        a = union(k[0],k[1],V)
        if a == 1:
            tree_edges.append(k)
            total_weight+=k[2]

    print(total_weight)
    print(tree_edges)

    output_file.write(str(total_weight) + '\n')
    for edges in tree_edges:
        for j in edges:
            output_file.write(str(j) + " ")
        output_file.write('\n')
    f.close()
    output_file.close()
