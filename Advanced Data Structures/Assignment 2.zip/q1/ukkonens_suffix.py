#Eric Horng
#26935449

#Acts as a pointer so globalend is changed in each edge class instance
#https://stackoverflow.com/questions/51336185/how-to-re-assign-a-variable-in-python-without-changing-its-id
class Num: 
    def __init__(self, num):
        self.num = num
    def __repr__(self):
        return f'{type(self).__name__}({self.num})'
    def __str__(self):
        return str(self.num)
    def __add__(self, other):
        return type(self)(self.num + other)
    def __radd__(self, other):
        return type(self)(other + self.num)
    def __iadd__(self, other):
        self.num += other
        return self

class Node:
    def __init__(self,suffix_link,is_leaf):
        if is_leaf:
            self.is_leaf = True
            self.leaf_number = suffix_link
        else:
            self.is_leaf = False
            self.suffix_link = suffix_link
            self.Edges = {}            

    def add_edge(self,edge,edge_label):
        self.Edges[edge_label] = edge

    def delete_edge(self,edge_label): #Remove by edge label
        self.Edges.pop(edge_label)

    def get_edge(self,edge_label):
        return self.Edges[edge_label]
    
class Edge:
    def __init__(self,first_char,last_char,dest):
        self.first_char = first_char
        self.last_char = last_char
        self.dest = dest
        
    def get_length(self):
        return self.last_char - self.first_char

class Suffix_Tree:
    def __init__(self,string):
        self.string = string
        self.str_length = len(string)
        self.Nodes = [Node(0,False)]#Root Node
        self.Leafs = []
        self.Active = 0
        self.GlobalEnd = Num(0)
        self.outstanding_node_current = None
        self.outstanding_node_old = None
        self.Remainder = None
        self.LastJ = 0

    def rule2a(self,i,j): #When at the active node, create a new leaf with new character not in the path
        self.Nodes.append(Node(j,True)) #Create a new leaf node
        self.Nodes[self.Active].add_edge(Edge(i+1,self.GlobalEnd,len(self.Nodes)-1),self.string[i+1]) #Create a new edge from active node to new leaf, with label char[i+1]

    def rule2b(self,i,j,split): #str[j...i]
        Original_Edge = self.Nodes[self.Active].get_edge(self.string[j])
        substring_split_idx = Original_Edge.first_char + split
        #Create a new internal node
        new_node = Node(-1,False)
        self.Nodes.append(new_node)
        self.outstanding_node_current = len(self.Nodes)-1
        #Create an edge from new internal node to old dest
        self.Nodes[len(self.Nodes)-1].add_edge(Edge(substring_split_idx,Original_Edge.last_char,Original_Edge.dest),self.string[split+1])
        #Create a new edge from active node to internal node
        self.Nodes[self.Active].delete_edge(self.string[j])
        self.Nodes[self.Active].add_edge(Edge(Original_Edge.first_char,substring_split_idx-1,len(self.Nodes)-1),self.string[Original_Edge.first_char])
        #Create a new leaf node
        self.Nodes.append(Node(j,True))
        #Create an edge from new internal node to new leaf
        self.Nodes[len(self.Nodes)-2].add_edge(Edge(i+1,self.GlobalEnd,len(self.Nodes)-1),self.string[i+1])

    def initialize(self):
        self.Nodes.append(Node(0,True)) #Create 1st leaf node
        self.Nodes[self.Active].add_edge(Edge(0,self.GlobalEnd,1),self.string[0])

    def traverse(self,start,end): #Given a substring starting at index 'start' and ending at index 'end' inclusive with skipcount
        char_traversed = start
        while char_traversed <= end:
            traverse_edge = self.Nodes[self.Active].get_edge(self.string[char_traversed])
            if end-char_traversed+1>traverse_edge.get_length(): #If we need to go further than this edge
                self.Active = traverse_edge.dest #Set the active node to the node at the end of the edge
                char_traversed += traverse_edge.get_length() #Skip the edge
            else: #Edge has remaining characters we still need to traverse
                return traverse_edge, end - char_traversed + 1 #Return how far into the edge that we have traversed
        
                
    def Ukkonens(self):
        self.initialize() #Create the first edge with the first character
        self.LastJ = 0
        self.GlobalEnd = Num(0)
        self.remainder_start = None
        self.remainder_end = None
        for i in range(1,self.str_length):
            self.GlobalEnd += 1
            showstopper = False
            self.outstanding_node_current = None
            self.outstanding_node_old = None
            for j in range(self.LastJ+1, i+2):
                if self.remainder_start == None: #remainder is empty string:
                    if self.string[i+1] in self.Nodes[self.Active].Edges:
                        showstopper = True
                    else:
                        self.rule2a(i,j)
                        self.LastJ += 1
                    self.outstanding_node_current = None
                else:
                    edge, extension_index = self.traverse(self.remainder_start,self.remainder_end)

                    #Make extensions
                    if edge.get_length() == extension_index: #Path ends at node
                        self.Active = edge.dest
                        if self.string[i+1] in self.Nodes[self.Active].Edges: #Extension implicitly in the tree
                            showstopper = True
                        else:
                            self.rule2a(i,j) #Extension not in tree, so add it according to rule 2a
                            self.LastJ += 1
                        self.outstanding_node_current = None
                        self.remainder_start = None #Since path ended at a node, remainder is empty string
                        self.remainder_end = None
                    else: #Path ended midway though an edge
                        if self.string[i+1] == self.string[edge.first_char + extension_index]: #Extension implicitely in the tree
                            print("Showstopper Rule")
                            self.remainder_end += 1
                            self.outstanding_node_current = None
                        else:
                            self.rule2b(i,j,extension_index)
                            self.LastJ += 1

                #Resolve Suffix links
                if self.outstanding_node_old is not None and self.outstanding_node_current is not None:
                    self.Nodes[self.outstanding_node_old].suffix_link = self.outstanding_node_current
                elif self.outstanding_node_old is not None and self.outstanding_node_current is None:
                    self.Nodes[self.outstanding_node_old].suffix_link = self.Active
                self.outstanding_node_old = self.outstanding_node_current    

                #Move to next extension
                if showstopper:
                    break
                else:
                    self.follow_suffix()

    def follow_suffix(self):
        #Follow suffix links
        if self.Active == 0: #if at root, stay where you are but remove first char before traversing
            self.remainder_start += 1
            if self.remainder_end < self.remainder_start: #If remainder is only 1 char long, removing it leaves empty string
                self.remainder_end = None
                self.remainder_start = None
        else:
            self.Active = self.Nodes[self.Active].suffix_link #Follow suffix link on active node

txt_file = open("txt.txt","r")
txt = txt_file.read()
txt = "abacabad"
txt = txt + "$"

a = Suffix_Tree(txt)
a.Ukkonens()
