#Eric Horng
#26935449

#Refs: https://en.wikipedia.org/wiki/Burrows%E2%80%93Wheeler_transform
#https://en.wikipedia.org/wiki/Suffix_array

#Program uses naive suffix tree construction to create suffix tree.
#An attempt at Ukkonens can be found in ukkonens_suffix, however couldnt get it to
#work properly, having trouble incorperating remainder

import naive_suffix
import sys

def DFS(suffix_array,nodes,nodeidx):
    current_node = nodes[nodeidx]
    if current_node.is_leaf is True:
        return current_node.label

    edge_labels = sorted(current_node.Edges) #Sort lexographically
    for edges in edge_labels:
        suffix_array.append(DFS(suffix_array,nodes,current_node.Edges[edges].dest))

if __name__ == '__main__':
    filename = sys.argv[1]
    with open(filename,'r') as txt_file:
        txt = txt_file.read()
        txt = txt + '$'
        suffix_tree = naive_suffix.Naive_Suffix_Tree(txt)
        suffix_tree.build()
        suffix_array = []

        #Do a lexographical depth-first search to get leaf nodes
        DFS(suffix_array,suffix_tree.nodes,0)

        #Get BWT from original text
        BWT = []
        for k in range(len(suffix_array)):
            if suffix_array[k] is not None:
                BWT.append(txt[suffix_array[k]-1])
        BWT = ''.join(BWT)
        print(BWT)

        with open("output_bwt.txt",'w+') as output_file:
            output_file.write(BWT)
            
        
    
    
