#Eric Horng
#ID:26935449
import sys
from GusZAlgo import Z_Algo
###############################################################
#Modified KMP
###############################################################
def modified_kmp(txt,pat):
    output_file = open("output_kmp.txt","w+")
    pat_size = len(pat)

    SP = [[0]*pat_size for i in range(26)]
    Z = Z_Algo(pat)
    Last_SP = 0
    #Once a mismatch has occured, need to avoid comparing the mismatched
    #character. Hence find the longest prefix with the mismatched character after it.  
    for j in range(pat_size-1,0,-1):
        i = j + Z[j]-1
        x = ord(pat[Z[j]])-97 #Get the character immediately after the z-box
        SP[x][i] = Z[j]+1 #Save the Z-box value in the relevant character entry. Add one so we skip the mismatched character as we know what it is
        if i==pat_size-1:
            Last_SP = Z[j] #Save SP(pat_size) in case match is found
            
    i = 0 #Pattern pointer
    j = 0 #Txt pointer
    Matches = []
    while j<len(txt):
        if pat[i]!=txt[j]:
            #print("j(" + str(txt[j]) + "):" + str(j) + " i(" + str(pat[i]) + "):" + str(i)+ " MISMATCH")
            if i==0: #Mismatch on the first character
                j+=1
            else: #Consult SP table
                i=SP[ord(txt[j])-97][i-1]
                j+=1
        else: #Compared characters are a match
            #print("j(" + str(txt[j]) + "):" + str(j) + " i(" + str(pat[i]) + "):" + str(i))
            i+=1
            j+=1
            if i==pat_size:
                print("Match at :" + str(j-pat_size+1)) #Added 1 for 1-based indexing
                i=Last_SP
                Matches.append(j-pat_size+1)
                output_file.write(str(j-pat_size+1) + "\n")
    output_file.close()
###############################################################
#Main
###############################################################                
if __name__ == '__main__':
    txt_file = open(sys.argv[1],"r")
    pat_file = open(sys.argv[2],"r")
    
    txt = txt_file.read()
    pat = pat_file.read()
    modified_kmp(txt,pat)
    txt_file.close()
    pat_file.close()


