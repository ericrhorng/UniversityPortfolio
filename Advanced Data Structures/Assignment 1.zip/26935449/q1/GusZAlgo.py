#Eric Horng
#ID: 26935449

###############################################################
#Gusfield's Z Algorithm
###############################################################
def Z_Algo(string):
    Z = [0]*len(string)
    Z[0] = -1 #Doesn't really matter as Z[0] undefined
    l = 0
    r = 0

    for k in range(1,len(string)):
        if k>r: #Case 1   
            q = 0
            while k+q<len(string) and string[q]==string[k+q]:
                q+=1
            Z[k] = q
            if q>0:
                l = k
                r = k+q-1
        else:
            if Z[k-l] < r-k+1: #Case 2a
                Z[k] = Z[k-l]
            else: #Case 2b
                q = r+1
                while q<len(string) and string[q]==string[q-k]:
                    q+=1
                Z[k] = q-k
                l = k
                r = q-1
    return Z
