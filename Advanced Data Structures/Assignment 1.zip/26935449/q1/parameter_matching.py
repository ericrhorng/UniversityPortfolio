#Eric Horng
#ID:26935449
from re import sub #Regular expression package to convert lower case letters
from GusZAlgo import Z_Algo
import sys

#############################################################
#Boyer-Moore Exact Pattern Matching from lectures. Only accepts [A-Z] and '[' to limit
#bad character table size
###############################################################
def Boyer_Moore_Parameter(txt,pat):
    pat_size = len(pat)
    #Create Bad Character Jump Table (Only handles tokens (i.e. uppercase) and parameter replacement '[' )
    BadCharTable = [-1]*27        
    BadCharTable = [BadCharTable]
    for x in range(pat_size-1):
        temp = BadCharTable[-1].copy()
        temp[ord(pat[x])-65]= x #Normalize so position converted to ASCII of A is 0
        BadCharTable.append(temp)
    
    #Create Good Suffix Table
    Good_Suffix = [-1]*(pat_size+1)
    Z_Suffix = Z_Algo(pat[::-1])[::-1] #Reverse input to Z_Algo then reverse again
    for p in range(pat_size-1):
        j = pat_size-Z_Suffix[p]
        Good_Suffix[j]=p

    #Create Matched Prefix Table
    Matched_Prefix = [0]*(pat_size+1)
    Z_PrefixofSuffix = Z_Algo(pat+"?"+pat)
    Z_PrefixofSuffix = Z_PrefixofSuffix[pat_size+1::]
    Longest_Prefix = 0
    for i in range(len(Z_PrefixofSuffix)-1,-1,-1):
        if Z_PrefixofSuffix[i]+i == pat_size:
            Matched_Prefix[i] = Z_PrefixofSuffix[i]
        else:
            Matched_Prefix[i] = Matched_Prefix[i+1]

    #Boyer-Moore Search Algorithm
    Start = pat_size -1
    Stop = -1
    Matches = []

    while Start < len(txt):
        i = pat_size-1 #First character in pat to compare
        j = Start #First character in txt to compare
        #print("Comparing " + str(txt[j-pat_size+1:j+1]) + " at " + str(j))
        #print("Comparing " + str(pat) + " pat")
        while i>=0 and j>=Stop and pat[i]==txt[j]: #Right to left compare
            i-=1 
            j-=1

        if i==-1: #All characters have matched
            print("Match found at index: " + str(Start-pat_size+1))
            #print("Match: " + str(txt[Start-pat_size+1:Start+1]))
            Matches.append(Start-pat_size+1)
            Start += pat_size - Matched_Prefix[1]    
        else: #Mismatch has occured at some i,j
            #print("Mismatch with: " + str(pat[i]) + " " + str(txt[j]) + " at " + str(j))
            Bad_Character_Shift = i - BadCharTable[i][ord(txt[j])-65]
            
            if Good_Suffix[i+1] ==-1: #Use Matched Prefix as Good Suffix entry is 0
                Good_Suffix_Shift = pat_size - Matched_Prefix[i+1]
            else:
                Good_Suffix_Shift = pat_size - Good_Suffix[i+1]-1
            #print("BadChar: " + str(Bad_Character_Shift) + " Good Suffix: " + str(Good_Suffix_Shift))
            Shift = max(Good_Suffix_Shift,Bad_Character_Shift)
            if Shift>= i+1:
                Stop = Start
            Start+=Shift
            #print("Jumping: " + str(Shift))

    return Matches
#############################################################
#Function to normalize p-strings so first parameter is always a, second is b...etc
#e.g. aBc->aBb xKOLpwp->aKOLbcb
#Should be O(m)
#############################################################
def Normalize(string):
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    Mapping_Table = [-1]*26
    Normalized_String = []
    j = 0
    for k in range(len(string)):
        if string[k].islower():
            if Mapping_Table[ord(string[k])-97]==-1:
                Mapping_Table[ord(string[k])-97] = alphabet[j]
                Normalized_String.append(alphabet[j])
                j+=1
            else:
                Normalized_String.append(Mapping_Table[ord(string[k])-97])
        else:
            Normalized_String.append(string[k])
    return ''.join(Normalized_String)
#############################################################
#Main
#############################################################
if __name__ == '__main__':
    txt_file = open(sys.argv[1],"r")
    pat_file = open(sys.argv[2],"r")
    output_file = open("output_parameter_matching.txt","w+")

    txt = txt_file.read()
    pat = pat_file.read()

    #Replace all parameters with [ (next char after Z in ascii) for exact string matching
    txt_aug = sub("[a-z]","[",txt) #I realise you can do this on a character by character basis when preproccesing to make the program faster but Im lazy and this is simple
    pat_aug = sub("[a-z]","[",pat)

    Matches = Boyer_Moore_Parameter(txt_aug,pat_aug)
    Normalized_Pat = Normalize(pat)
    True_Matches = []

    for i in range(len(Matches)):
        Normalized_String = Normalize(txt[Matches[i]:Matches[i]+len(pat)]) #Find original string in txt and normalize
        x = 0
        is_mismatch = 0 #Flag
        while x<len(pat) and is_mismatch==0:
            if Normalized_Pat[x]!=Normalized_String[x]:
                is_mismatch=1
            x+=1
        if is_mismatch==0:
            output_file.write(str(Matches[i]+1)+"\n") #One-based indexing
            True_Matches.append(Matches[i]+1) #Debugging
            
    print("True Matches: " + str(True_Matches))
    output_file.close()
    txt_file.close()
    pat_file.close()
    
    


        
