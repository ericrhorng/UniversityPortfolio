#Eric Horng
#ID:26935449
from GusZAlgo import Z_Algo
import sys
#############################################################
#Boyer-Moore Exact Pattern Matching from lectures. For Binary
#############################################################
#Removed Bad Character Table as it is very unlikely for the pattern to
#only consist of 0's or 1's. Shifting to the next 1 or 0 can be handled
#by the good suffix rule

#Tried experimenting with hashing groups of bits into a single character
#or integer, but could not figure out how to shift in the case when a pattern
#crosses the boundary between two defined hashings e.g. 100 010 with pat 001
#Maybe if I shifted the entire text by 1 and 2 bits if word size=3, and compared
#between the original and the two right shifted txts so I get all permutations
#and follow the shift rule as before?

def Binary_BM(txt,pat):
    output_file = open("output_binary_boyermoore.txt","w+")
    pat_size = len(pat)
    
    #Create Good Suffix Table
    Good_Suffix = [-1]*(pat_size+1)
    Z_Suffix = Z_Algo(pat[::-1])[::-1]
    for p in range(pat_size-1):
        j = pat_size-Z_Suffix[p]
        Good_Suffix[j]=p

    #Create Matched Prefix Table
    Matched_Prefix = [0]*(pat_size+1)
    Z_PrefixofSuffix = Z_Algo(pat+"?"+pat)
    Z_PrefixofSuffix = Z_PrefixofSuffix[pat_size+1::]
    Longest_Prefix = 0
    for i in range(len(Z_PrefixofSuffix)-1,-1,-1):
        if Z_PrefixofSuffix[i]+i == pat_size:
            Matched_Prefix[i] = Z_PrefixofSuffix[i]
        else:
            Matched_Prefix[i] = Matched_Prefix[i+1]

    #Boyer-Moore Search Algorithm
    Start = pat_size -1
    Stop = -1
    Matches = []
    Comparisons = 0

    while Start < len(txt):
        i = pat_size-1 #First character in pat to compare
        j = Start #First character in txt to compare
        while i>=0 and j>=Stop and pat[i]==txt[j]: #Right to left compare
            Comparisons+=1
            i-=1 
            j-=1

        if i==-1: #All characters have matched
            Matches.append(Start-pat_size+1)
            output_file.write(str(Start-pat_size+1+1) + "\n") #+1 for 1-indexing
            Start += pat_size - Matched_Prefix[1]    
        else: #Mismatch has occured at some i,j
            
            if Good_Suffix[i+1] ==-1: #Use Matched Prefix as Good Suffix entry is 0
                Good_Suffix_Shift = pat_size - Matched_Prefix[i+1]
            else:
                Good_Suffix_Shift = pat_size - Good_Suffix[i+1]-1
            Shift = Good_Suffix_Shift
            if Shift>= i+1:
                Stop = Start
            Start+=Shift

    output_file.close()
    return Comparisons
#############################################################
#Main
#############################################################
if __name__ == '__main__':
    txt_file = open(sys.argv[1],"r")
    pat_file = open(sys.argv[2],"r")
    txt = txt_file.read()
    pat = pat_file.read()

    Comps = Binary_BM(txt,pat)
    print("Comparisons: " + str(Comps))
