#Eric Horng
#26935449

import sys

def elias_decode(txt,pos): #pos is first bit in the elias-omega code word  
    component = 0
    readlen = 1
    integer = None
    while True:
        component = txt[pos:pos+readlen]
        if component[0] == '1':
            integer = int(component,2)
            return integer, pos + readlen #returns position of first bit after code word

        component = '1' + component[1::]
        pos += readlen
        readlen = int(component,2) + 1

def decoder(input_file):
    with open(input_file,'r') as file:
        txt = file.read()

    #====================Header=======
    #Get number of unique chars
    num_of_chars, pos = elias_decode(txt,0)

    char_dict = {}
    for k in range(num_of_chars):
        #Get the 7-bit ascii code
        ascii_ = txt[pos:pos+7]
        char = chr(int(ascii_,2))
        pos += 7

        #Get elias-w code for length of huffman code
        len_huffman, pos = elias_decode(txt,pos)

        #Get huffman code and store in dictionary
        char_dict[txt[pos:pos+len_huffman]] = char
        pos+=len_huffman

    #====================Data=========
    #Get number of LZSS fields
    num_LZ, pos = elias_decode(txt,pos)

    LZSS = []

    for k in range(num_LZ):
        field_type = int(txt[pos]) #Get format of the field
        pos += 1

        if field_type == 0: #Triple
            offset, pos = elias_decode(txt,pos)
            length, pos = elias_decode(txt,pos)
            LZSS.append(tuple((0,offset,length)))
        elif field_type == 1: #Tuple
            #Get the huffman code directly
            code = txt[pos]
            i = 1
            while code not in char_dict: #As huffman is a prefix code, first match is always correct
                i += 1
                code = txt[pos:pos+i]
            LZSS.append(tuple((1,char_dict[code])))
            pos += i

    #Use LZSS to reconstruct txt
    reconst_txt = ''
    for k in range(len(LZSS)):
        if len(LZSS[k]) == 2:
            reconst_txt += LZSS[k][1] #Add char directly to string
        else:
            offset = LZSS[k][1]
            length = LZSS[k][2]
            pointer = len(reconst_txt) - offset
            for j in range(length):
                reconst_txt += reconst_txt[pointer]
                pointer += 1

    with open('output_decoder_lzss.txt','w+') as file:
        file.write(reconst_txt)
    #print(reconst_txt)

if __name__ == '__main__':    
    input_file = sys.argv[1]
    decoder(input_file)
