#Eric Horng
#26935449

import sys
import heapq

def elias_omega(integer, root): #Root = True if integer is the one you want to encode and not one of the recursive L's
    if integer == 1:
        if root is False:
            return '0'
        else:
            return '1' #Base case when the encoded integer is 1
        
    binary = "{0:b}".format(integer) #Convert to a minimal binary string

    if root is False: #Only change leading character to 0 if not original encoded integer  
        binary = '0'+ binary[1::] #Strings are immutable
    return elias_omega(len(binary)-1,False) + binary

class HuffmanNode:
    def __init__(self,string, frequency, left_child = None, right_child = None):
        self.string = string
        self.frequency = frequency
        self.left_child = left_child
        self.right_child = right_child
        
    def __lt__(self,other):
        return self.frequency < other.frequency
    
    def get_code(self, dictionary, path):
        if len(self.string) == 1:
            dictionary[self.string] = path
            return
        
        if self.left_child is not None:
            self.left_child.get_code(dictionary,path + '0')
        
        if self.right_child is not None:
            self.right_child.get_code(dictionary,path + '1')  

class HuffmanNode:
    def __init__(self,string, frequency, left_child = None, right_child = None):
        self.string = string
        self.frequency = frequency
        self.left_child = left_child
        self.right_child = right_child
        
    def __lt__(self,other):
        return self.frequency < other.frequency
    
    def get_code(self, dictionary, path):
        if len(self.string) == 1:
            dictionary[self.string] = path
            return
        
        if self.left_child is not None:
            self.left_child.get_code(dictionary,path + '0')
        
        if self.right_child is not None:
            self.right_child.get_code(dictionary,path + '1')  

def huffman(txt):
    #Get the frequency of each character in string
    char_dict = {}
    for char in txt:
        char_dict[char] = char_dict.get(char, 0) + 1
        
    #Base case when txt only consists of one character
    if len(char_dict) == 1:
        huffman_dict = {}
        huffman_dict[list(char_dict.keys())[0]] = '0'
        return huffman_dict

    #Add characters to a heapq
    heap = []
    for key in char_dict:
        new_node = HuffmanNode(key,char_dict[key])
        heapq.heappush(heap,new_node)
    
    #Perform huffman algorithm to get codes
    while len(heap) > 1:
        node1 = heapq.heappop(heap) #node1 <= node2
        node2 = heapq.heappop(heap)
        
        new_node = HuffmanNode(node1.string+node2.string,node1.frequency+node2.frequency,node1,node2)
        heapq.heappush(heap,new_node)
    
    root_node = heapq.heappop(heap)
    
    #Do a depth first search to get huffman codes
    huffman_dict = {}
    root_node.get_code(huffman_dict,'')
    
    return huffman_dict

if __name__ == '__main__':
    input_file = sys.argv[1]
    
    with open(input_file,'r') as file:
        txt = file.read()
    huffman_dict = huffman(txt)
    header = ''
    
    #Elias omega code for number of unique characters
    header += elias_omega(len(huffman_dict),True)
    
    for char in huffman_dict:
        header += '{0:07b}'.format(ord(char)) #Fixed length 7-bit ascii
        header += elias_omega(len(huffman_dict[char]),True) #Length of huffman code in elias_omega
        header += huffman_dict[char] #Huffman code
    
    with open('output_header.txt','w+') as output_file:
        output_file.write(header)
    print(header)
