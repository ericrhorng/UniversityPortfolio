#Eric Horng
#26935449

import random
import math
import sys

def repeated_squaring(a,b,n):
    #a base, b exponent, n modulo
    binary = "{0:b}".format(b) #Convert to a binary string which we can access
    num_of_bits = len(binary)
    result = 1
    previous = a % n #a^1 mod n
    
    if binary[-1] == '1': #Case where lsb in number is 1
        result = (result * previous) % n
    
    for k in range(num_of_bits-2,-1,-1): #start from 2nd-most lsb to msb
        current = (previous * previous) % n
        if binary[k] == '1':
            result = (result * current) % n
        previous = current
    return result

def miller_rabin(n,k):
    if n % 2 == 0:
        return False
    s = 0
    t = n-1
    while t % 2: #While t is even
        s+=1
        t = t/2
        
    for i in range(k):
        a = random.randint(2,n-2) #[2...n-1)
        if repeated_squaring(a,n-1,n) != 1:
            return False
        
        cache = [0] * (s+1)
        cache[0] = repeated_squaring(a,t,n)
        for j in range(1,s+1): #[1...s]
            cache[j] = repeated_squaring(a,(2**j)*t,n)
            
            if cache[j] == 1 and (cache[j-1] != 1 or cache[j-1] != -1):
                return False
    return True

def generate_prime(m):
    lower_bound = 2**(m-1)
    upper_bound = 2**m-1
    
    #Calculated number of expected primes in the range
    expected_primes = math.ceil(upper_bound/math.log(upper_bound) - lower_bound/math.log(lower_bound)) + 1

    #Thus, the chance of picking a prime would be 1/(upper-lower)/num_primes
    iterations = math.ceil((upper_bound-lower_bound)/expected_primes)
    
    for k in range(iterations):
        #Primes will always be odd. Any number ending in 5 that is greater than 10 is not a prime as well
        n = random.randrange(lower_bound+1,upper_bound+1,2) #Generate a random odd number of m-bits
        
        #Probability a composite will be prime is 4^-k so, 4^-9 is a small enough probability in my opinion
        expected_witnesses = 9
        if miller_rabin(n,expected_witnesses):
            return n
        
    return None

if __name__ == '__main__':
    m = int(sys.argv[1])
    if m == 1: #Base case
        print("There are no 1-bit primes")
    elif m == 2: #Doesnt return 2 due to the way I calculate n (by adding 1 to lower bound, i miss out on 2)
        print("Primes are 2 and 3")
    else:
        prime = generate_prime(m)
        if prime is None:
            print('No primes found.')
        else:
            print(prime)
