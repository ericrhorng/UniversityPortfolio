Project overview:
    This project utilises the IBM's Watson AI to produce a facial recognition program. Server.js is run
using node server.js and a webpage can be accessed at "localhost:3000" in an internet browser.The image is 
then uploaded to Watson computer and the AI can recognise faces in the image, their gender, age, and position 
of the face. The result is output to the user both in text and audio. In addition, the program can also point 
out the position of the faces in the photo.
 
Requires: 
Nodejs and a suitable browser
 
Npm Packages: 
express
socketio-file-upload
socket.io-stream
watson-developer-cloud
winston
 
Tested on:
Mocha and Chai testing library

Release Features:
-Webpage now shows original image, output image with locations of faces
-Cleaned up webpage (removed upload button, less clutter)

App Features:
-	Facial recognition to determine age, gender, and location on picture
-	Result in form of text and audio (text to speech)
-	Capable of supporting multiple clients

Limitations:
-	Some features such as canvas may not work in older browsers
-   The facial recognition and text to speech functions have a limited amount of uses since we are using
    an IBM Lite account. May need to upgrade to a paid account if usage is more than expected.

