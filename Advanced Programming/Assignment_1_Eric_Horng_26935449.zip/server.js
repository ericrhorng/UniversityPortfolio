var fs =require('fs')
         , http=require('http')
         , socketio=require('socket.io');

var player1= false;
var player2= false;
var CurrentTurn= 1;
var waitinglist=0;
var grid=[[-1,-1,-1],[-1,-1,-1],[-1,-1,-1]];
var DisconnectedArray=[];

//Server initialization from Week 2 lab
var server=http.createServer(function(req, res) {
            res.writeHead(200, { 'Content-type': 'text/html'});
            res.end(fs.readFileSync(__dirname+'/homepage.html'));
            }).listen(8080, function() {
            console.log('Listening at: http://localhost:8080');
 });

socketio.listen(server).on('connection', function (socket) {
    //Assign players on connection
    console.log('User connected');
    waitinglist+=1;
    if (player1==false){
        ResetBoard();
        player1=true;
        socket.emit('PlayerAssignment',{waitinglist});
        BroadcastAll('ServerMessage','Player 1 Connected');
        console.log('Assigned Player 1');
    }
    else if (player1==true && player2==false){
        ResetBoard();
        player2=true;
        socket.emit('PlayerAssignment',{waitinglist});
        BroadcastAll('ServerMessage','Player 2 Connected');
        console.log('Assigned Player 2')
    }
    else{
        socket.emit('PlayerAssignment',{waitinglist});
        BroadcastAll('ServerMessage','User connected. Waiting list is: ' + String(waitinglist-2));
    };
    
    socket.on('disconnect',function(a){
        //Send a handshake to all players to see which client has disconnected.
        BroadcastAll('Handshake');
        DisconnectedArray=[]; //Clear the disconnectedarray upon a new disconnection
        if (waitinglist==1){//Once everyone has left, reset the server
            player1= false;
            player2= false;
            CurrentTurn= 1;
            waitinglist=0;
            grid=[[-1,-1,-1],[-1,-1,-1],[-1,-1,-1]];
        }
        
    });
    
    socket.on('Response',function(PlayerResponse){
        //Once the server recieves a response, add the player to an array
        DisconnectedArray.push(PlayerResponse);    
        //Once all responses have been collected, search through the array to find the user which has disconnceted using .indexOf (which returns -1 when it cant find it)
        if (DisconnectedArray.length==waitinglist-1){
            for (i=1;i<waitinglist+1;i++){
                if (DisconnectedArray.indexOf(i)<0){
                    var DisconnectedPlayer=i;
                    console.log('User ' + i +' Disconnected')
                    break;
                };    
            };
            if (DisconnectedPlayer==2 || DisconnectedPlayer==1){
                ResetBoard();
                var Disconnected='Player ' + String(DisconnectedPlayer) + ' Disconnected';
                BroadcastAll('ServerMessage',Disconnected);
                BroadcastAll('Reshuffle',DisconnectedPlayer);
                
                //Case where there was a waiting list, everyone but 1 has left and expecting a new user
                if (waitinglist==2){
                    if (DisconnectedPlayer==1){
                        player1=false;
                    }
                    else{
                        player2=false;
                    };
                };                
            }
            else{
                BroadcastAll('Reshuffle',DisconnectedPlayer);
            };
            waitinglist-=1;            
        };
    });
    
    //Update grid and winner checking
    socket.on('GridInput', function (gridcoord) {
        //Check turn was sent by correct player
        if (CurrentTurn==gridcoord.player){
            //Check if move is valid
            if (grid[gridcoord.row][gridcoord.column]==-1){
                //Switch turns
                if (CurrentTurn==1){
                    CurrentTurn=2;
                }
                else{
                    CurrentTurn=1;  
                };
                //Update grid with player number and broadcast new grid along with the current turn
                grid[gridcoord.row][gridcoord.column]=gridcoord.player;
                BroadcastAll('UpdateGrid',{CurrentTurn,grid});
            }
            else{
                socket.emit('InvalidMove');
            };
        }
        else{
          socket.emit('NotYourTurn');  
        };
        
        //Check if anyone has won
        var winner=CheckWinner(grid);
        if (winner!=false){
          BroadcastAll('Win',winner);
          var winnermessage='Player '+ String(winner) + ' has won!';    
          BroadcastAll('ServerMessage',winnermessage);
        };
        
    });
    
    //Reset board
    socket.on('Reset',function(){
        console.log('Reset Recieved')
        ResetBoard();
        BroadcastAll('ServerMessage','Game Reset');
    });
    
    //CUSTOM FUNCTIONS USING SOCKETIO
    function ResetBoard(){
        grid=[[-1,-1,-1],[-1,-1,-1],[-1,-1,-1]];
        CurrentTurn=1;
        socket.broadcast.emit('UpdateGrid',{CurrentTurn,grid});
        socket.emit('UpdateGrid',{CurrentTurn,grid});
    };
    
    function BroadcastAll(type,data){
        socket.broadcast.emit(type,data)
        socket.emit(type,data)    
    };
});

//Lazy way of checking winner
function CheckWinner(grid){
    //Check rows
    if (grid[0][0]!=-1 && grid[0][0]==grid[0][1] && grid[0][1]==grid[0][2]){
      return grid[0][0];  
    };
    
    if (grid[1][0]!=-1 && grid[1][0]==grid[1][1] && grid[1][1]==grid[1][2]){
      return grid[1][0];  
    };
    
    if (grid[2][0]!=-1 && grid[2][0]==grid[2][1] && grid[2][1]==grid[2][2]){
      return grid[2][0];  
    };
    
    //Check columns
    if (grid[0][0]!=-1 && grid[0][0]==grid[1][0] && grid[1][0]==grid[2][0]){
      return grid[0][0];  
    };
    
    if (grid[0][1]!=-1 && grid[0][1]==grid[1][1] && grid[1][1]==grid[2][1]){
      return grid[0][1];  
    };
    
    if (grid[0][2]!=-1 && grid[0][2]==grid[1][2] && grid[1][2]==grid[2][2]){
      return grid[0][2];  
    };

    //Check diagonals
    if (grid[0][0]!=-1 && grid[0][0]==grid[1][1] && grid[1][1]==grid[2][2]){
      return grid[0][0];  
    };
    
    if (grid[2][0]!=-1 && grid[2][0]==grid[1][1] && grid[1][1]==grid[0][2]){
      return grid[0][2];  
    };
    return false
};




