% Creating State-Space Equations
close all
clc

% Parameters
g = 9.8;
mass2 = 1;
length1 = 1;
length2 = 0.8;
lengthc1 = length1 / 2;
lengthc2 = length2 / 2;
mInertia1 = (1/3)*mass1*(length1^2);
mInertia2 = (1/3)*mass2*(length2^2);

torque = [0 0];

syms theta1 theta2 dtheta1_dt dtheta2_dt
syms torque1 torque2

syms z1 z2 z3 z4
syms v1 v2

X_topleft = mInertia1 + mInertia2 + (mass2*(length1.^2)) + (2*mass2*length1*lengthc2*cos(theta2));
X_topright = mInertia2 + (mass2*length1*lengthc2*cos(theta2));
X_bottomleft = mInertia2 + (mass2*length1*lengthc2*cos(theta2));
X_bottomright = mInertia2;
X = [X_topleft, X_topright;X_bottomleft, X_bottomright];

Y_top = torque1 + (2*mass2*length1*lengthc2*sin(theta2)*dtheta1_dt*dtheta2_dt) + (mass2*length1*lengthc2*sin(theta2)*(dtheta2_dt.^2)) - ((mass1*lengthc1+mass2*length1)*g*sin(theta1)) - (mass2*g*length2*sin(theta1+theta2));
Y_bottom = torque2 - (mass2*length1*lengthc2*sin(theta2)*(dtheta1_dt.^2)) - (mass2*g*length2*sin(theta1+theta2));
Y = [Y_top;Y_bottom];

% F Matrix
F(theta1, theta2, dtheta1_dt, dtheta2_dt, torque1, torque2) = [dtheta1_dt;dtheta2_dt;X\Y];

% Set x values to z and torque values to v
linearized_F_values(z1, z2, z3, z4, v1, v2) = subs(F, {theta1, theta2, dtheta1_dt, dtheta2_dt, torque1, torque2}, {z1, z2, z3, z4, v1, v2});
% Specify equilibrium points
upwards_equilibrium_point = [pi, 0, 0, 0];
downwards_equilibrium_point = [0, 0, 0, 0];
equilibrium_point = upwards_equilibrium_point;

% Work out partial derivatives
linearized_F(z1,z2,z3,z4,v1,v2) = linearized_F_values(z1+equilibrium_point(1),z2+equilibrium_point(2),z3+equilibrium_point(3),z4+equilibrium_point(4), torque(1), torque(2));
linearized_F1_z1(z1,z2,z3,z4,v1,v2) = diff(linearized_F, z1);
linearized_F1_z2(z1,z2,z3,z4,v1,v2) = diff(linearized_F, z2);
linearized_F1_z3(z1,z2,z3,z4,v1,v2) = diff(linearized_F, z3);
linearized_F1_z4(z1,z2,z3,z4,v1,v2) = diff(linearized_F, z4);

% Create A matrix with zero input torque
A = [];
A(:,1) = linearized_F1_z1(equilibrium_point(1),equilibrium_point(2),equilibrium_point(3),equilibrium_point(4), torque(1), torque(2));
A(:,2) = linearized_F1_z2(equilibrium_point(1),equilibrium_point(2),equilibrium_point(3),equilibrium_point(4), torque(1), torque(2));
A(:,3) = linearized_F1_z3(equilibrium_point(1),equilibrium_point(2),equilibrium_point(3),equilibrium_point(4), torque(1), torque(2));
A(:,4) = linearized_F1_z4(equilibrium_point(1),equilibrium_point(2),equilibrium_point(3),equilibrium_point(4), torque(1), torque(2));

% Create B matrix with zero input torque
B = [];
linearized_F1_v1 = diff(linearized_F_values, v1);
linearized_F1_v2 = diff(linearized_F_values, v2);
B(:,1) = linearized_F1_v1(equilibrium_point(1),equilibrium_point(2),equilibrium_point(3),equilibrium_point(4), torque(1), torque(2));
B(:,2) = linearized_F1_v2(equilibrium_point(1),equilibrium_point(2),equilibrium_point(3),equilibrium_point(4), torque(1), torque(2));

C = eye(4);
D = 0;

% Stability of system
poles = eig(A);
if (sum(real(poles) > 0) ~= 0)
    disp("System is not stable");
else
    disp("System is stable");
end

% Controllability of system
rank_controllability_matrix = rank(ctrb(A,B));
if rank_controllability_matrix == 4
    disp("System is controllable");
else 
    disp("System is not controllable");
end

% Use LQR method to find K matrix
Q = diag([1000,1000,1,1]);
R = diag([0.01,0.01]);
[Kd,S, eigenvalues_dt] = lqrd(A,B,Q,R,Ts);

% Get zero order hold equivalent system
sys = ss(A,B,C,D);
sys_discrete = c2d(sys, Ts, 'zoh');
[A,B,C,D] = ssdata(sys_discrete);

% Work out desired eigenvalues for settling time and overshoot
settling_time = 0.3;
a = (1/settling_time)*log(0.02);
percentage_overshoot = 0.02;
b = (pi*a)/(log(percentage_overshoot));
eval1 = a+1i*b;
eval2 = a-1i*b;

% Determine K matrix using place function (OLD)
%desired_poles_discrete = exp([eval1;eval2;6*a;7*a].*Ts);
%[Kd, prec] = place(A,B,desired_poles_discrete);

sys_discrete_gain = ss(A-B*Kd,B,C,0, Ts);

figure(1)
pzmap(sys_discrete_gain);
grid on
xlim([-1 1])
ylim([-1 1])

figure(2)
step(sys_discrete_gain,10)
