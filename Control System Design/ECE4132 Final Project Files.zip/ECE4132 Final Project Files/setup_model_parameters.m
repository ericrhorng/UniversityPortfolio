% setup model parameters
clear;
close all;

% put the student id of one group member in here and use it consistently
%id = 25952625; 
id = 26935449; 

% setup parameters of "real" planar robot system
% the variable Fplanar_robot needs to be in your workspace for the "real"
% system simulation to run
Fplanar_robot = setup_planar_robot(id);

% system initial condition (change as necessary)
% this will be the initial condition for the "real" system and for your
% ideal model of the system. 
xinit = [0;0;0;0]; % downwards
%xinit = [pi-0.01;0;0;0] % nearly upwards with no velocity

% input torque saturation for the "real" system (change only for "additional goals")
sat1 = 10;
sat2 = 10;

% discrete-time sampling period (change only for "additional goals")
%Ts = 0.05;
Ts = 0.05;
% measurement noise level for the "real" system (change only for "additional goals")
var = 0.0025;
%var = 0.025;
% default value for the mass of the first pendulum. Changing this value
% will change your ideal simulated model, but not the "real" system.
% goal 2 requires you to find the value of this parameter from data.
% use this value for goal 1.
%mass1 = 0.54342; %25952625
mass1 = 0.66283; %26935449
%mass1 = 1;