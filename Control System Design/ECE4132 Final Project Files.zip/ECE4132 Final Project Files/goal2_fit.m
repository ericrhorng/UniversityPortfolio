% fit parameters of planar robot
setup_model_parameters;
% fill in the initial condition to something reasonable
xinit = [pi/4;0;0;0];

% try a range of different values of the mass of the first pendulum:
% m1s should be a vector consisting of different possible values of mass1 from which you want to find the best one.
m1s = linspace(0.65816, 0.66633,8);
error = zeros(length(m1s),1);

for ii=1:length(m1s)
    mass1 = m1s(ii);
    fprintf('Trying the mass of %0.5f\n', mass1);
    sim('goal2'); % simulate the simulink model goal2.slx
    
    error(ii) = sim_error.signals.values(:,1)'*sim_error.signals.values(:,1) + sim_error.signals.values(:,2)'*sim_error.signals.values(:,2);
    fprintf('Mass:\t%0.5f\terror:\t%0.8f\n', mass1, error(ii));
    % compute the sum of the squares of the error between the simulated
    % response and the response of the "real" system.
end

[minval, minidx] = min(error);
% print out best value of mass1
best_mass1 = m1s(minidx);
fprintf("Most optimal mass: %0.5fkg - Error: %0.8f\n",best_mass1, error(minidx));
