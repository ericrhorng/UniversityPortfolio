% Goal one: Implement an Ideal Model of the System
function F = Fmy_planar_robot(x, torque, mass1)
	% Parameters
    g = 9.8;
    mass2 = 1;
    length1 = 1;
    length2 = 0.8;
    lengthc1 = length1 / 2;
    lengthc2 = length2 / 2;
    mInertia1 = (1/3)*mass1*(length1^2);
    mInertia2 = (1/3)*mass2*(length2^2);
	
	% Set up matrices
    A_topleft = mInertia1 + mInertia2 + (mass2*(length1.^2)) + (2*mass2*length1*lengthc2*cos(x(2)));
    A_topright = mInertia2 + (mass2*length1*lengthc2*cos(x(2)));
    A_bottomleft = mInertia2 + (mass2*length1*lengthc2*cos(x(2)));
    A_bottomright = mInertia2;
    A = [A_topleft, A_topright;A_bottomleft, A_bottomright];
    
    B_top = torque(1) + (2*mass2*length1*lengthc2*sin(x(2))*x(3)*x(4)) + (mass2*length1*lengthc2*sin(x(2))*(x(4).^2)) - ((mass1*lengthc1+mass2*length1)*g*sin(x(1))) - (mass2*g*length2*sin(x(1)+x(2)));
    B_bottom = torque(2) - (mass2*length1*lengthc2*sin(x(2))*(x(3).^2)) - (mass2*g*length2*sin(x(1)+x(2)));
    B = [B_top;B_bottom];
    
    F = A\B;
end